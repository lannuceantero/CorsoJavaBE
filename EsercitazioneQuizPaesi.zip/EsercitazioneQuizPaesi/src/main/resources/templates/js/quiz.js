    const regioni = document.getElementById("regioni")
		const paesi = document.getElementById("paesi")
		const URL_REGIONI = '/api/regioni'
		const URL_PAESI = '/api/paesi'
		
		fetch(URL_REGIONI)
			.then(res => res.json())
			.then(regions =>
				{
					for(const regione of regions)
					{
						const LI = document.createElement('li')
						LI.textContent = regione

						LI.onclick = function()
						{
							fetch(URL_PAESI + '/' + regione)
							.then(res => res.json())
							.then(paesis => {
								paesi.innerHTML = ''
								for(const paese of paesis)
								{
									const LI = document.createElement('li')
									LI.textContent = paese.name
									paesi.append(LI)
								}
							})
						}
						regioni.append(LI)
					}
				}
			)