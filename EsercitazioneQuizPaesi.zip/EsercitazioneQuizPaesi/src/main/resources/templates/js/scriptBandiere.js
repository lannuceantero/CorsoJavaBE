
// document.getElementById("buttons").addEventListener("click", domandaCapitale);


const URL_PAESI = 'http://localhost:9030/api/paesi'

		fetch(URL_PAESI)
			.then(res => 
                {
                    res.json();}
                )       
			.then(data =>
				{
                    let quizcap =
                    {
                        'domanda': '',
                        'risposte': [],
                        'risposta': ''
                    }
                    
                    

					let paeseRandom=data[Math.floor(Math.random()* data.length)];
					let capitalErrata=data[Math.floor(Math.random()* data.length)];

                        quizC.domanda=paeseRandom.name;
                        quizC.risposte.push(paeseRandom.capital);

                        document.querySelector('#eldomanda').textContent=quizC.domanda;
                        document.querySelector('#box1').textContent=quizC.risposte[0];
                        document.querySelector('#box2').textContent=quizC.risposte[1];
                        document.querySelector('#box3').textContent=quizC.risposte[2];
                        document.querySelector('#risposta').textContent=quizC.risposta;
					});/**
 * 
 */