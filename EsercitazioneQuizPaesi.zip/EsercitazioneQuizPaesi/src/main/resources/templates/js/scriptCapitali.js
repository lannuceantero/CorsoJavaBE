const URL_PAESI = 'http://localhost:9030/api/paesi'

		fetch(URL_PAESI)
			.then(res => 
                {
                   return res.json();}
                )       
			.then(data =>
				{
                    console.log(data);
                    // let quizcap =
                    // {
                    //     'domanda': '',
                    //     'risposte': [],
                    //     'risposta': '',
                    //     'risposta2': ''
                    // }

					// let paeseRandom=data[Math.floor(Math.random()* data.length)];
					// let capitalErrata=data[Math.floor(Math.random()* data.length)];

                    //      quizcap.domanda=paeseRandom.name;
                    //      quizcap.risposte.push(paeseRandom.capital);

                    //     document.querySelector('#eldomanda').textContent=quizcap.domanda;
                    //     document.querySelector('#box1').textContent=quizcap.risposte[0];
                    //     document.querySelector('#box2').textContent=quizcap.risposta;
                    //     document.querySelector('#box3').textContent=quizcap.risposta2;
                       
					});