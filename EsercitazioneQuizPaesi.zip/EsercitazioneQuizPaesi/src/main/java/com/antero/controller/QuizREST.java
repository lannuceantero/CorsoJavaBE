package com.antero.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.antero.entities.Paese;
import com.antero.services.PaeseService;

@RestController  //RestController ritorna JSON
@RequestMapping("api")
public class QuizREST     //A partire da questa classe cioè QuizREST, possiamo fare il cammino inverso, cioè:
{						 //Io chiedo al SERVICE, SERVICE chiede ao DAO che chiede al DB e mi restituisce ciò che ho chiesto.
	
	
	@Autowired       //INVERSIONE DEL CONTROLLO, ci pensa Spring a creare questo oggetto quando mi serve
	private PaeseService service; 
	
	
	@GetMapping("paesi")  								 //ok http://localhost:9030/api/paesi
	List <Paese> getPaesi()
	{
		return service.getPaesi();
		
	}
	
	@GetMapping("paesi/region/{region}")  // ok  http://localhost:9030/api/paesi/region/Europe
	List <Paese> getPaesi(@PathVariable String region)
	{
		return service.getPaesiByRegione(region);
		
	}
	
	@GetMapping("paesi/capital/{capital}")    // ok http://localhost:9030/api/paesi/capital/brasilia
	List <Paese> getPaesiByCapital(@PathVariable String capital)
	{
		return service.getByCapital(capital);
		
	}
	
	@GetMapping("regioni")				// ok   http://localhost:9030/api/regioni	
	List <String> getRegioni()        
	{
		return service
				.getPaesi()
				.stream()  //filtro 
				.map(p -> p.getRegion())  //dato un paese, estrago solo una proprietà Regione
				.distinct() //lo distinguo 
				.sorted() //lo ordino
				.toList(); //lo trasformo in una stringa  -> infatti il ritorno sarà una List<String> 
	}
	
	
	@GetMapping ("paese/name/{name}")   //ok http://localhost:9030/api/paese/name/brazil
	Paese getPaese(@PathVariable String name)
	{
		return service.getPaeseByName(name);
	}
	
	
	@GetMapping("paese/capital/{capital}")      //ok http://localhost:9030/api/paese/brasilia
	Paese getPaeseByCapital(@PathVariable String capital)
	{
		return service.getPaeseByCapital(capital);
	}
	
	
	
	
	
	
	
}
