package com.antero.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller  //Controller torna delle stringhe che corrisponde a delle pagine html che si trovano nella cartella templates
public class Router 
{

	@GetMapping("quiz")   //tutto ciò che chiami qua 
	String home()
	{
		return "quiz";   //deve risalire ad un file nella cartella templetas
	}
	
	@GetMapping("quizcapitali")   //tutto ciò che chiami qua 
	String home2()
	{
		return "quizcapitali";   //deve risalire ad un file nella cartella templetas
	}
	
	@GetMapping("quizbandiere")   //tutto ciò che chiami qua 
	String home3()
	{
		return "quizbandiere";   //deve risalire ad un file nella cartella templetas
	}
	
	
	
}
