package com.antero.repos;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.antero.entities.Paese;

public interface PaeseDAO extends JpaRepository<Paese, Integer> 
{
	//sito consigliato per approfondire sull'argomento:  baeldung.com/spring-data-derived-queries
	
	Paese findPaeseByCapital (String capital);
	
	Paese findByName (String name);
	
	
	List <Paese> findByCapital(String capital);
	
	//QUERY LIKE  	-    Derived query
	List <Paese> findByRegion(String region); //SELECT * FROM ....
	
	//QUERY NATIVA        -> questa la devi scrivere TU, se la vuoi "personalizzata"
	@Query(value = "SELECT distinct(region) as region FROM countries", nativeQuery = true)
	List <Paese> trovaRegioniDistinte(String region);
	
}
