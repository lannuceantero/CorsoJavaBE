package com.antero.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.antero.entities.Paese;
import com.antero.repos.PaeseDAO;

@Service
public class PaeseServiceImpl implements PaeseService 
{
	
	@Autowired
	private PaeseDAO dao;
	
	@Override
	public List<Paese> getPaesi() 
	{
		return dao.findAll();
	}

	@Override
	public List<Paese> getPaesiByRegione(String region) 
	{
		return dao.findByRegion(region);
	}
	
	@Override
	public List<Paese> getByCapital(String capital) 
	{
		return dao.findByCapital(capital);
	}

	@Override
	public Paese getPaeseByCapital(String capital) 
	{
		return dao.findPaeseByCapital(capital);
	}

	@Override
	public Paese getPaeseByName(String name) 
	{
		return dao.findByName(name);	
	}

	

}
