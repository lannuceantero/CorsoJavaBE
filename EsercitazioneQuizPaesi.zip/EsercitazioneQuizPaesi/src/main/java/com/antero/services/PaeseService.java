package com.antero.services;

import java.util.List;

import com.antero.entities.Paese;

public interface PaeseService 
{
	//Service faccio tutti questi servizi per mettere a disposizione al piano di sopra cioè al controller

	List <Paese> getPaesi(); //prento tutta la lista di paesi
	
	List <Paese> getPaesiByRegione(String region); //prendo una lista di paesi in base alla regione
	
	List <Paese> getByCapital(String capital);
	
	Paese getPaeseByCapital(String capital);  //prendo un paese a partire da una capital
	
	Paese getPaeseByName(String name); //prendo un paese a partire dal suo nome e ottengo sia capitale che regione di appartenenza
	
}
